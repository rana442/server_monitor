<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MonitorController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Middleware\AdminMiddleware;

// Simple Auth Routes
Route::middleware('guest')->group(function () {
    // Login
    Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('login', [LoginController::class, 'login']);
    
    // Register
    Route::get('register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('register', [RegisterController::class, 'register']);
});

// Logout
Route::post('logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

// User Routes
Route::middleware(['auth'])->group(function () {
    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    
    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::post('/profile/theme', [ProfileController::class, 'toggleTheme'])->name('profile.theme');
    
    // Monitors (User)
    Route::get('/monitors/{monitor}', [MonitorController::class, 'show'])->name('monitors.show');
    Route::get('/monitors/{monitor}/logs', [MonitorController::class, 'logs'])->name('monitors.logs');
});

// Admin Routes - সরাসরি middleware ক্লাস ব্যবহার করুন
Route::middleware(['auth', AdminMiddleware::class])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::resource('/monitors', MonitorController::class)->except(['show']);
    Route::get('/users', [AdminController::class, 'users'])->name('users.index');
    Route::get('/system-logs', [AdminController::class, 'systemLogs'])->name('system.logs');
});