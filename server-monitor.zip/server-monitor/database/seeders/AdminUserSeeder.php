<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\UserSetting;

class AdminUserSeeder extends Seeder
{
    public function run()
    {
        // Create admin user
        $admin = User::create([
            'name' => 'Administrator',
            'email' => 'admin@example.com',
            'password' => bcrypt('admin123'),
            'is_admin' => true,
            'email_verified_at' => now(),
        ]);

        // Create user settings
        UserSetting::create([
            'user_id' => $admin->id,
            'dark_mode' => true,
        ]);

        // Create regular user
        $user = User::create([
            'name' => 'Regular User',
            'email' => 'user@example.com',
            'password' => bcrypt('user123'),
            'is_admin' => false,
            'email_verified_at' => now(),
        ]);

        UserSetting::create([
            'user_id' => $user->id,
            'dark_mode' => true,
        ]);
    }
}