

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <h1 class="h3 mb-0">
            <i class="bi bi-speedometer2"></i> Server Status Dashboard
        </h1>
        <p class="text-muted">Last updated: <?php echo e(now()->format('Y-m-d H:i:s')); ?></p>
    </div>
</div>

<div class="row mb-4">
    <!-- Stats Cards -->
    <div class="col-md-3 mb-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Monitors</h5>
                <h2 class="mb-0"><?php echo e($totalMonitors); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Up</h5>
                <h2 class="mb-0"><?php echo e($upMonitors); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h5 class="card-title">Down</h5>
                <h2 class="mb-0"><?php echo e($downMonitors); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Avg. Uptime</h5>
                <h2 class="mb-0"><?php echo e(number_format($avgUptime, 2)); ?>%</h2>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="bi bi-list-check"></i> All Monitors
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>URL</th>
                        <th>Status</th>
                        <th>Last Check</th>
                        <th>Uptime</th>
                        <th>Duration</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($monitor->name); ?></td>
                        <td>
                            <a href="<?php echo e($monitor->url); ?>" target="_blank" class="text-decoration-none">
                                <?php echo e(Str::limit($monitor->url, 30)); ?>

                                <i class="bi bi-box-arrow-up-right ms-1"></i>
                            </a>
                        </td>
                        <td>
                            <?php if($monitor->last_status): ?>
                            <span class="badge status-badge status-up">
                                <i class="bi bi-check-circle"></i> UP
                            </span>
                            <?php else: ?>
                            <span class="badge status-badge status-down">
                                <i class="bi bi-x-circle"></i> DOWN
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($monitor->last_checked_at): ?>
                            <?php echo e($monitor->last_checked_at->diffForHumans()); ?>

                            <?php else: ?>
                            <span class="text-muted">Never</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar <?php echo e($monitor->uptime_percentage > 95 ? 'bg-success' : ($monitor->uptime_percentage > 80 ? 'bg-warning' : 'bg-danger')); ?>"
                                     role="progressbar"
                                     style="width: <?php echo e($monitor->uptime_percentage); ?>%">
                                    <?php echo e(number_format($monitor->uptime_percentage, 1)); ?>%
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if($monitor->last_status && $monitor->last_up_at): ?>
                            <span class="badge bg-success duration-badge">
                                <?php echo e($monitor->last_up_at->diffForHumans(['parts' => 2, 'short' => true])); ?>

                            </span>
                            <?php elseif(!$monitor->last_status && $monitor->last_down_at): ?>
                            <span class="badge bg-danger duration-badge">
                                <?php echo e($monitor->last_down_at->diffForHumans(['parts' => 2, 'short' => true])); ?>

                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('monitors.show', $monitor)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\server-monitor\resources\views/dashboard/index.blade.php ENDPATH**/ ?>