

<?php $__env->startSection('title', 'Manage Monitors'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h3 mb-0">
                    <i class="bi bi-list-check"></i> Manage Monitors
                </h1>
                <a href="<?php echo e(route('admin.monitors.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add New Monitor
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>URL</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Interval</th>
                            <th>Uptime</th>
                            <th>Last Check</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $monitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($monitor->id); ?></td>
                            <td><?php echo e($monitor->name); ?></td>
                            <td>
                                <a href="<?php echo e($monitor->url); ?>" target="_blank" class="text-decoration-none">
                                    <?php echo e(Str::limit($monitor->url, 30)); ?>

                                    <i class="bi bi-box-arrow-up-right ms-1"></i>
                                </a>
                            </td>
                            <td>
                                <span class="badge bg-info text-uppercase">
                                    <?php echo e($monitor->type); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($monitor->last_status === true): ?>
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle"></i> UP
                                </span>
                                <?php elseif($monitor->last_status === false): ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-x-circle"></i> DOWN
                                </span>
                                <?php else: ?>
                                <span class="badge bg-secondary">
                                    <i class="bi bi-question-circle"></i> UNKNOWN
                                </span>
                                <?php endif; ?>
                                
                                <?php if($monitor->is_active): ?>
                                <span class="badge bg-primary ms-1">Active</span>
                                <?php else: ?>
                                <span class="badge bg-warning ms-1">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($monitor->interval); ?>s</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="progress flex-grow-1" style="height: 20px;">
                                        <div class="progress-bar <?php echo e($monitor->uptime_percentage > 95 ? 'bg-success' : ($monitor->uptime_percentage > 80 ? 'bg-warning' : 'bg-danger')); ?>"
                                             role="progressbar"
                                             style="width: <?php echo e($monitor->uptime_percentage); ?>%">
                                            <?php echo e(number_format($monitor->uptime_percentage, 1)); ?>%
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if($monitor->last_checked_at): ?>
                                <?php echo e($monitor->last_checked_at->diffForHumans()); ?>

                                <?php else: ?>
                                <span class="text-muted">Never</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('monitors.show', $monitor)); ?>" 
                                       class="btn btn-sm btn-outline-primary" title="View">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.monitors.edit', $monitor)); ?>" 
                                       class="btn btn-sm btn-outline-warning" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.monitors.destroy', $monitor)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                onclick="return confirm('Are you sure?')" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="bi bi-inbox fs-1"></i>
                                    <p class="mt-2">No monitors found. Create your first monitor!</p>
                                    <a href="<?php echo e(route('admin.monitors.create')); ?>" class="btn btn-primary mt-2">
                                        <i class="bi bi-plus-circle"></i> Add Monitor
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($monitors->hasPages()): ?>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($monitors->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\server-monitor\resources\views/admin/monitors/index.blade.php ENDPATH**/ ?>