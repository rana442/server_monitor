<?php

namespace App\Http\Controllers;

use App\Models\Monitor;
use Illuminate\Http\Request;

class MonitorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $monitors = Monitor::latest()->paginate(10);
        return view('admin.monitors.index', compact('monitors'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.monitors.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'required',
            'type' => 'required|in:http,ping,port',
            'interval' => 'required|integer|min:1|max:300',
        ]);

        Monitor::create([
            'name' => $request->name,
            'url' => $request->url,
            'type' => $request->type,
            'interval' => $request->interval,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('admin.monitors.index')
            ->with('success', 'Monitor created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Monitor $monitor)
    {
        $logs = $monitor->pingLogs()->latest()->paginate(20);
        return view('monitors.show', compact('monitor', 'logs'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Monitor $monitor)
    {
        return view('admin.monitors.edit', compact('monitor'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Monitor $monitor)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'required',
            'type' => 'required|in:http,ping,port',
            'interval' => 'required|integer|min:1|max:300',
        ]);

        $monitor->update([
            'name' => $request->name,
            'url' => $request->url,
            'type' => $request->type,
            'interval' => $request->interval,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('admin.monitors.index')
            ->with('success', 'Monitor updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Monitor $monitor)
    {
        $monitor->delete();
        
        return redirect()->route('admin.monitors.index')
            ->with('success', 'Monitor deleted successfully.');
    }

    /**
     * Show monitor logs
     */
    public function logs(Monitor $monitor)
    {
        $logs = $monitor->pingLogs()->latest()->paginate(50);
        return view('monitors.logs', compact('monitor', 'logs'));
    }
}