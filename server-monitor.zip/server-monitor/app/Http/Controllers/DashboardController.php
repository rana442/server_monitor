<?php

namespace App\Http\Controllers;

use App\Models\Monitor;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $monitors = Monitor::where('is_active', true)->get();
        
        $totalMonitors = $monitors->count();
        $upMonitors = $monitors->where('last_status', true)->count();
        $downMonitors = $monitors->where('last_status', false)->count();
        $avgUptime = $monitors->avg('uptime_percentage') ?? 0;
        // return auth()->user();
        
        return view('dashboard.index', compact(
            'monitors',
            'totalMonitors',
            'upMonitors',
            'downMonitors',
            'avgUptime'
        ));
    }
}