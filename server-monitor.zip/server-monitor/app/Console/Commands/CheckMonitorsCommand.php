<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Monitor;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class CheckMonitorsCommand extends Command
{
    protected $signature = 'monitors:check';
    protected $description = 'Check all active monitors';

    public function handle()
    {
        $monitors = Monitor::where('is_active', true)->get();

        foreach ($monitors as $monitor) {
            $this->checkMonitor($monitor);
        }

        $this->info('All monitors checked successfully.');
    }

    private function checkMonitor(Monitor $monitor)
    {
        try {
            $startTime = microtime(true);
            
            $response = Http::timeout(5)->get($monitor->url);
            $responseTime = round((microtime(true) - $startTime) * 1000); // Convert to milliseconds
            
            $status = $response->successful();
            $statusCode = $response->status();
            
            // লগ তৈরি
            $monitor->pingLogs()->create([
                'status' => $status,
                'response_time' => $responseTime,
                'status_code' => $statusCode,
                'response_body' => $status ? null : $response->body(),
            ]);

            // স্ট্যাটাস আপডেট
            $monitor->last_checked_at = now();
            $monitor->last_status = $status;
            
            if ($status && !$monitor->last_status) {
                $monitor->last_up_at = now();
            } elseif (!$status && $monitor->last_status) {
                $monitor->last_down_at = now();
            }
            
            $monitor->save();
            
            // আপটাইম ক্যালকুলেট
            $monitor->calculateUptime();

        } catch (\Exception $e) {
            // ডাউন স্ট্যাটাস
            $monitor->pingLogs()->create([
                'status' => false,
                'error_message' => $e->getMessage(),
            ]);

            $monitor->last_checked_at = now();
            $monitor->last_status = false;
            
            if ($monitor->last_status !== false) {
                $monitor->last_down_at = now();
            }
            
            $monitor->save();
            $monitor->calculateUptime();
            
            Log::error("Monitor check failed for {$monitor->name}: " . $e->getMessage());
        }
    }
}