<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        Commands\CheckMonitorsCommand::class,
    ];

    protected function schedule(Schedule $schedule)
    {
        // প্রতি ৩ সেকেন্ডে মোনিটর চেক (Cron expression ব্যবহার করে)
        $schedule->command('monitors:check')
            ->cron('*/3 * * * * *') // প্রতি ৩ সেকেন্ডে
            ->withoutOverlapping()
            ->runInBackground();
        
        // অথবা প্রতি ১০ সেকেন্ডে (টেস্টের জন্য)
        $schedule->command('monitors:check')
            ->everyTenSeconds()
            ->withoutOverlapping()
            ->runInBackground();
            
        // Debug: প্রতি মিনিটে একটি লগ লিখুন
        $schedule->call(function () {
            \Log::info('Scheduler is running at: ' . now());
        })->everyMinute();
    }

    protected function commands()
    {
        $this->load(__DIR__.'/Commands');
        require base_path('routes/console.php');
    }
}